//
//  ___FILEHEADER___
//

import Foundation

@MainActor
final class ___VARIABLE_sceneName:identifier___ViewModel: ObservableObject, Sendable {
        
    init() {
        setUp()
    }
}

private extension ___VARIABLE_sceneName:identifier___ViewModel {
    func setUp() {
    }
}
