//
//  ___FILEHEADER___
//

import SwiftUI

struct ___VARIABLE_sceneName:identifier___View: View {
    @StateObject private var viewModel = ___VARIABLE_sceneName:identifier___ViewModel()

    var body: some View {
        Text("Add some view here")
    }
}

struct ___VARIABLE_sceneName:identifier___View_Previews: PreviewProvider {
    static var previews: some View {
        ___VARIABLE_sceneName:identifier___View()
    }
}
