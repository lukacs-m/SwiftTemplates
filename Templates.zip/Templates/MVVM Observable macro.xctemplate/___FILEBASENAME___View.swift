//
//  ___FILEHEADER___
//

import SwiftUI

struct ___VARIABLE_sceneName:identifier___View: View {
    @State private var viewModel = ___VARIABLE_sceneName:identifier___ViewModel()

    var body: some View {
        Text("Add some view here")
    }
}

#Preview {
        ___VARIABLE_sceneName:identifier___View()
}
