//
//  ___FILEHEADER___
//

import Foundation

@Observable @MainActor
final class ___VARIABLE_sceneName:identifier___ViewModel: Sendable {
        
    init() {
        setUp()
    }
}

private extension ___VARIABLE_sceneName:identifier___ViewModel {
    func setUp() {
    }
}
