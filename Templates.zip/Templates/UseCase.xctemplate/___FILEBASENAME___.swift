//
//  ___FILEHEADER___
//

protocol ___VARIABLE_productName___UseCase: Sendable {
   // func execute() async throws
}

extension ___VARIABLE_productName___UseCase {
    func callAsFunction() {
      // execute()
    }
}

final class ___VARIABLE_productName___: ___VARIABLE_protocolName___ {
        
    init() {}
    
    // func execute() async throws
}
